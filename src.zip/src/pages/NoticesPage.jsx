import { useState, useMemo } from 'react'
import {
  FileText,
  Search,
  Filter,
  Download,
  Calendar,
  Pin,
  Eye,
  AlertCircle,
  Bell,
  CheckCircle,
} from 'lucide-react'
import { notices } from '../data/content'
import { addSubmission } from '../lib/siteStore'
import { useLanguage } from '../context/LanguageContext'

export default function NoticesPage() {
  const { lang, num } = useLanguage()
  const noticeList = notices[lang] || notices.bn

  const allLabel = lang === 'bn' ? 'সকল নোটিশ' : 'All'
  const [selectedCat, setSelectedCat] = useState(allLabel)
  const [searchQuery, setSearchQuery] = useState('')
  const [subscribed, setSubscribed] = useState(false)
  const [mobileNum, setMobileNum] = useState('')

  const categories = useMemo(() => [allLabel, ...new Set(noticeList.map((n) => n.cat))], [noticeList, allLabel])

  const filteredNotices = useMemo(() => {
    return noticeList.filter((n) => {
      const matchCat = selectedCat === allLabel || n.cat === selectedCat
      const matchSearch =
        n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.text.toLowerCase().includes(searchQuery.toLowerCase())
      return matchCat && matchSearch
    })
  }, [noticeList, selectedCat, allLabel, searchQuery])

  const pinnedNotices = filteredNotices.filter((n) => n.pinned)
  const regularNotices = filteredNotices.filter((n) => !n.pinned)

  const handleSubscribe = (e) => {
    e.preventDefault()
    if (!mobileNum) return
    addSubmission('subscriber', { phone: mobileNum, lang })
    setSubscribed(true)
    setTimeout(() => {
      setMobileNum('')
      setSubscribed(false)
    }, 4000)
  }

  const handleDownloadNotice = (notice) => {
    alert(lang === 'bn' ? `ডাউনলোড করা হচ্ছে: "${notice.title}" এর অফিশিয়াল পিডিএফ` : `Downloading official PDF document for: "${notice.title}"`)
  }

  return (
    <div className="min-h-screen bg-paper py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Page Header Banner */}
        <div className="bg-gradient-to-r from-board via-boardlt to-iris rounded-3xl p-8 sm:p-12 text-chalk mb-10 shadow-xl relative overflow-hidden">
          <div className="max-w-3xl relative z-10">
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-white/10 text-gold border border-white/15 mb-3">
              <FileText className="w-3.5 h-3.5 text-gold" />
              <span>{lang === 'bn' ? 'অফিসিয়াল সার্কুলার ও নোটিশ বোর্ড' : 'Official Circulars & Notice Board'}</span>
            </span>
            <h1 className="font-display font-extrabold text-3xl sm:text-5xl text-white tracking-tight">
              {lang === 'bn' ? 'বিদ্যালয় নোটিশ বোর্ড' : 'School Notice Board'}
            </h1>
            <p className="mt-3 text-sm sm:text-base text-chalk/80 leading-relaxed">
              {lang === 'bn'
                ? 'মিরাশানী একাডেমি প্রশাসন কর্তৃক প্রকাশিত সকল একাডেমিক পরীক্ষার রুটিন, ছুটির ঘোষণা, ভর্তি সার্কুলার এবং গুরুত্বপূর্ণ নোটিশ এক নজরে দেখুন।'
                : 'Stay updated with academic examination routines, holiday declarations, admission circulars, and official announcements published by the Mirashani Academy administration.'}
            </p>
          </div>
          <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 opacity-10 pointer-events-none">
            <FileText className="w-96 h-96 text-white" />
          </div>
        </div>

        {/* Search & Filter Toolbar */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-ink/10 shadow-md mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 no-scrollbar">
            <Filter className="w-4 h-4 text-ink/50 shrink-0 hidden sm:block" />
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCat(cat)}
                className={`px-3.5 sm:px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                  selectedCat === cat
                    ? 'bg-board text-chalk shadow-md scale-105'
                    : 'bg-paper text-ink/75 hover:bg-ink/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-ink/40 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={lang === 'bn' ? 'নোটিশ খুঁজুন...' : 'Search notices by keyword...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-xl border border-ink/20 text-xs sm:text-sm focus:ring-2 focus:ring-iris/30 focus:border-iris outline-none"
            />
          </div>
        </div>

        {/* Pinned / Urgent Notices */}
        {pinnedNotices.length > 0 && (
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <Pin className="w-4 h-4 text-brick fill-brick" />
              <h2 className="font-display font-bold text-lg text-board uppercase tracking-wider">
                {lang === 'bn' ? 'পিন করা ও জরুরি ঘোষণা' : 'Pinned & Important Announcements'}
              </h2>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              {pinnedNotices.map((n) => (
                <div
                  key={n.id}
                  className="bg-white rounded-2xl p-6 border-2 border-brick/40 shadow-lg hover:shadow-xl transition-all relative overflow-hidden"
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-brick bg-brick/10 px-3 py-1 rounded-full">
                      <AlertCircle className="w-3.5 h-3.5" />
                      {n.cat} &middot; {lang === 'bn' ? 'জরুরি' : 'Urgent'}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-ink/60">
                      <Calendar className="w-3.5 h-3.5" />
                      {num(n.date)}
                    </span>
                  </div>

                  <h3 className="font-display font-extrabold text-xl text-board mb-2">{n.title}</h3>
                  <p className="text-sm text-ink/75 leading-relaxed mb-4">{n.text}</p>

                  <div className="pt-4 border-t border-ink/10 flex items-center justify-between">
                    <span className="text-xs text-ink/50 font-medium">
                      {lang === 'bn' ? 'প্রকাশক:' : 'Issued by:'} {n.author}
                    </span>
                    <button
                      onClick={() => handleDownloadNotice(n)}
                      className="btn inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-board text-chalk text-xs font-bold hover:bg-boardlt shadow-sm"
                    >
                      <Download className="w-3.5 h-3.5 text-gold" />
                      <span>{lang === 'bn' ? 'পিডিএফ ডাউনলোড' : 'Download PDF'}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Regular Notices Grid */}
        <div>
          <h2 className="font-display font-bold text-lg text-board mb-4">
            {lang === 'bn' ? 'সাম্প্রতিক সকল নোটিশ' : 'All Recent Circulars'}
          </h2>
          {regularNotices.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-ink/10">
              <FileText className="w-12 h-12 text-ink/30 mx-auto mb-3" />
              <p className="font-display font-bold text-lg text-board">
                {lang === 'bn' ? 'কোনো নোটিশ পাওয়া যায়নি' : 'No notices found'}
              </p>
              <p className="text-sm text-ink/60 mt-1">
                {lang === 'bn' ? 'অনুসন্ধান রিসেট করুন বা অন্য বিভাগ নির্বাচন করুন।' : 'Try clearing your search query or selecting another category.'}
              </p>
              <button
                onClick={() => {
                  setSelectedCat(allLabel)
                  setSearchQuery('')
                }}
                className="mt-4 px-4 py-2 rounded-xl bg-board text-chalk text-xs font-bold"
              >
                {lang === 'bn' ? 'রিসেট করুন' : 'Reset Filters'}
              </button>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {regularNotices.map((n) => (
                <div
                  key={n.id}
                  className="bg-white rounded-2xl p-6 border border-ink/10 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs mb-3">
                      <span className="font-bold text-iris uppercase tracking-wide bg-iris/10 px-2.5 py-0.5 rounded-full">
                        {n.cat}
                      </span>
                      <span className="text-ink/50 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {num(n.date)}
                      </span>
                    </div>

                    <h3 className="font-display font-bold text-lg text-board mb-2 leading-snug">{n.title}</h3>
                    <p className="text-xs sm:text-sm text-ink/75 leading-relaxed mb-4">{n.text}</p>
                  </div>

                  <div className="pt-4 border-t border-ink/10 flex items-center justify-between">
                    <span className="text-[11px] text-ink/50 font-medium">
                      {lang === 'bn' ? 'প্রকাশক:' : 'By:'} {n.author}
                    </span>
                    <button
                      onClick={() => handleDownloadNotice(n)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-iris hover:underline"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{lang === 'bn' ? 'রুটিন পিডিএফ' : 'PDF Routine'}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* SMS / Notice Notification Subscription Box */}
        <div className="mt-12 sm:mt-16 bg-gradient-to-r from-board via-boardlt to-iris rounded-2xl sm:rounded-3xl p-6 sm:p-8 text-chalk shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <Bell className="w-5 h-5 text-gold" />
              <h3 className="font-display font-bold text-lg sm:text-xl text-white">
                {lang === 'bn' ? 'এসএমএস অ্যালার্টের মাধ্যমে নোটিশ পান' : 'Get Instant Notices via SMS Alert'}
              </h3>
            </div>
            <p className="text-xs sm:text-sm text-chalk/80">
              {lang === 'bn'
                ? 'অভিভাবকগণ মোবাইল নম্বর নিবন্ধন করে সরাসরি পরীক্ষার রুটিন ও জরুরি ছুটির বার্তা পেতে পারেন।'
                : 'Guardians can subscribe their mobile number to receive exam schedules and emergency school closures directly.'}
            </p>
          </div>

          <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full md:w-auto">
            <input
              type="tel"
              placeholder={lang === 'bn' ? 'যেমন: ০১৭XXXXXXXX' : 'e.g. 017XXXXXXXX'}
              value={mobileNum}
              onChange={(e) => setMobileNum(e.target.value)}
              className="px-4 py-2.5 rounded-xl bg-white/10 text-white placeholder-chalk/50 border border-white/20 text-xs sm:text-sm outline-none focus:ring-2 focus:ring-gold flex-1 min-w-0"
              required
            />
            <button
              type="submit"
              className="btn px-5 py-2.5 rounded-xl bg-gold text-ink font-bold text-xs sm:text-sm hover:brightness-110 shadow-md shrink-0 cursor-pointer text-center"
            >
              {lang === 'bn' ? 'বিনামূল্যে সাবস্ক্রাইব' : 'Subscribe Free'}
            </button>
          </form>
        </div>

        {subscribed && (
          <div className="fixed bottom-6 right-6 z-50 bg-board text-white px-5 py-3 rounded-2xl shadow-2xl border border-gold flex items-center gap-3 animate-fadeIn">
            <CheckCircle className="w-5 h-5 text-mint" />
            <p className="text-xs font-bold">
              {lang === 'bn'
                ? 'ধন্যবাদ! আপনার মোবাইল নম্বর নোটিশ অ্যালার্টের জন্য নিবন্ধিত হয়েছে।'
                : 'Thank you! Your mobile number has been registered for notice alerts.'}
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
