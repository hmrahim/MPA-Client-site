import { useState } from 'react'
import {
  Clock,
  Printer,
  Edit2,
  CheckCircle2,
  User,
  MapPin,
  X
} from 'lucide-react'
import { useDashboard } from '../context/DashboardContext'

export default function RoutineManager() {
  const { weeklyRoutine, updateRoutineSlot, teachers } = useDashboard()

  const [selectedDay, setSelectedDay] = useState('Sunday')
  const [editingSlot, setEditingSlot] = useState(null)
  const [toastMessage, setToastMessage] = useState(null)

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday']
  const currentDaySlots = weeklyRoutine[selectedDay] || []

  const handleEditSlot = (day, idx, slot) => {
    setEditingSlot({
      day,
      idx,
      subject: slot.subject,
      teacher: slot.teacher,
      room: slot.room,
      time: slot.time
    })
  }

  const handleSaveSlot = (e) => {
    e.preventDefault()
    if (!editingSlot) return

    updateRoutineSlot(editingSlot.day, editingSlot.idx, {
      subject: editingSlot.subject,
      teacher: editingSlot.teacher,
      room: editingSlot.room,
      time: editingSlot.time
    })

    setEditingSlot(null)
    setToastMessage('✓ Routine period slot updated successfully!')
    setTimeout(() => setToastMessage(null), 3000)
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#16161f] text-white px-5 py-3 rounded-xl shadow-2xl border border-[#6c63ff]/40 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span className="font-semibold text-xs">{toastMessage}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 moom-card p-5">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold text-sky-400 bg-sky-500/10 border border-sky-500/20 px-2.5 py-1 rounded-full mb-1">
            <Clock className="w-3.5 h-3.5" />
            <span>Academic Timetable & Period Allocation</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            Weekly Class Routine Grid
          </h2>
          <p className="text-xs text-slate-400">
            Interactive timetable scheduler, faculty allocation, and room management
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="moom-btn-ghost px-4 py-2.5 rounded-xl text-xs font-bold inline-flex items-center gap-2"
        >
          <Printer className="w-4 h-4 text-[#a78bfa]" />
          <span>Print Routine Sheet</span>
        </button>
      </div>

      {/* Day Selector Pills */}
      <div className="flex flex-wrap items-center gap-2 moom-card p-3">
        {days.map((day) => (
          <button
            key={day}
            onClick={() => setSelectedDay(day)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              selectedDay === day
                ? 'bg-[#6c63ff] text-white shadow-[0_0_15px_rgba(108,99,255,0.4)]'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            {day}
          </button>
        ))}
      </div>

      {/* Period Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {currentDaySlots.map((slot, idx) => (
          <div
            key={idx}
            className="moom-card p-5 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="px-2.5 py-0.5 rounded-full bg-[#6c63ff]/10 text-[#a78bfa] border border-[#6c63ff]/20 text-[11px] font-black font-mono">
                  Period 0{slot.period}
                </span>
                <span className="text-[11px] font-mono font-semibold text-slate-400">{slot.time}</span>
              </div>

              <h3 className="font-black text-white text-base mb-1">{slot.subject}</h3>

              <div className="space-y-1.5 text-xs text-slate-300 mt-3 pt-3 border-t border-[#1e1e2e]">
                <div className="flex items-center gap-2">
                  <User className="w-3.5 h-3.5 text-[#a78bfa]" />
                  <span>{slot.teacher}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-rose-400" />
                  <span>{slot.room}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-[#1e1e2e] flex items-center justify-end">
              <button
                onClick={() => handleEditSlot(selectedDay, idx, slot)}
                className="inline-flex items-center gap-1.5 text-xs text-[#a78bfa] hover:text-white font-semibold transition"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit Slot</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit Slot Modal */}
      {editingSlot && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
          <div className="relative w-full max-w-md bg-[#111118] text-slate-200 rounded-2xl shadow-2xl overflow-hidden border border-[#1e1e2e]">
            <div className="px-6 py-4 bg-[#16161f] border-b border-[#1e1e2e] flex items-center justify-between">
              <h3 className="font-bold text-sm text-white">Edit Period Schedule (Period {editingSlot.idx + 1})</h3>
              <button onClick={() => setEditingSlot(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveSlot} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-400 mb-1">Subject</label>
                <input
                  type="text"
                  required
                  value={editingSlot.subject}
                  onChange={(e) => setEditingSlot({ ...editingSlot, subject: e.target.value })}
                  className="w-full moom-input"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-400 mb-1">Teacher</label>
                <select
                  value={editingSlot.teacher}
                  onChange={(e) => setEditingSlot({ ...editingSlot, teacher: e.target.value })}
                  className="w-full moom-select"
                >
                  {teachers.map((t) => (
                    <option key={t.id} value={t.name}>
                      {t.name} ({t.department})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-400 mb-1">Room / Lab</label>
                <input
                  type="text"
                  required
                  value={editingSlot.room}
                  onChange={(e) => setEditingSlot({ ...editingSlot, room: e.target.value })}
                  className="w-full moom-input"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-400 mb-1">Time Range</label>
                <input
                  type="text"
                  required
                  value={editingSlot.time}
                  onChange={(e) => setEditingSlot({ ...editingSlot, time: e.target.value })}
                  className="w-full moom-input font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#1e1e2e]">
                <button
                  type="button"
                  onClick={() => setEditingSlot(null)}
                  className="moom-btn-ghost px-4 py-2 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="moom-btn-primary px-5 py-2 rounded-xl font-bold shadow"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
