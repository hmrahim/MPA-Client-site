import { useState } from 'react'
import {
  GraduationCap,
  UserPlus,
  Search,
  Phone,
  Mail,
  BookOpen,
  Award,
  CheckCircle2,
  X
} from 'lucide-react'
import { useDashboard } from '../context/DashboardContext'

export default function TeacherManager() {
  const { teachers, addTeacher } = useDashboard()

  const [searchQuery, setSearchQuery] = useState('')
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [toastMessage, setToastMessage] = useState(null)

  const [formData, setFormData] = useState({
    name: '',
    designation: 'Assistant Teacher',
    department: 'Science Faculty',
    qualification: 'M.Sc / B.Ed',
    phone: '',
    email: '',
    salary: 35000,
    joinDate: '2026-01-01',
    assignedClass: 'Class 9',
    subjects: 'Physics, Mathematics'
  })

  const filteredTeachers = teachers.filter((t) => {
    const q = searchQuery.toLowerCase()
    return (
      !q ||
      t.name.toLowerCase().includes(q) ||
      t.department.toLowerCase().includes(q) ||
      t.designation.toLowerCase().includes(q)
    )
  })

  const handleCreateTeacher = (e) => {
    e.preventDefault()
    if (!formData.name || !formData.phone) {
      alert('Please enter teacher name and phone number.')
      return
    }

    addTeacher({
      ...formData,
      subjects: typeof formData.subjects === 'string' ? formData.subjects.split(',').map((s) => s.trim()) : formData.subjects
    })

    setIsAddModalOpen(false)
    setFormData({
      name: '',
      designation: 'Assistant Teacher',
      department: 'Science Faculty',
      qualification: 'M.Sc / B.Ed',
      phone: '',
      email: '',
      salary: 35000,
      joinDate: '2026-01-01',
      assignedClass: 'Class 9',
      subjects: 'Physics, Mathematics'
    })
    setToastMessage('✓ New faculty member appointed successfully!')
    setTimeout(() => setToastMessage(null), 3500)
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#16161f] text-white px-5 py-3 rounded-xl shadow-2xl border border-[#6c63ff]/40 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span className="font-semibold text-xs">{toastMessage}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 moom-card p-5">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold text-sky-400 bg-sky-500/10 border border-sky-500/20 px-2.5 py-1 rounded-full mb-1">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Faculty & Academic Staff Directory</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            Teachers & Faculty Council
          </h2>
          <p className="text-xs text-slate-400">
            Designations, assigned departments, salary structures and staff profiles
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="moom-btn-primary px-4 py-2.5 rounded-xl text-xs font-bold inline-flex items-center gap-2"
        >
          <UserPlus className="w-4 h-4" />
          <span>Appoint Faculty</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="moom-card p-4 flex items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search by faculty name or department..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full moom-input pl-9"
          />
        </div>
        <span className="text-xs font-bold text-slate-400">
          Total Faculty: <strong className="text-white">{teachers.length}</strong>
        </span>
      </div>

      {/* Faculty Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredTeachers.map((tch) => (
          <div
            key={tch.id}
            className="moom-card p-5 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start gap-3.5 mb-4">
                <img
                  src={tch.avatar}
                  alt={tch.name}
                  className="w-14 h-14 rounded-2xl object-cover border border-[#1e1e2e] shadow"
                />
                <div>
                  <h3 className="font-black text-white text-sm leading-tight">{tch.name}</h3>
                  <p className="text-[11px] font-bold text-[#a78bfa] mt-0.5">{tch.designation}</p>
                  <span className="text-[10px] text-slate-400 font-medium block">{tch.department}</span>
                </div>
              </div>

              <div className="space-y-2 text-xs text-slate-300 bg-[#16161f] p-3.5 rounded-xl border border-[#1e1e2e]">
                <div className="flex items-center gap-2">
                  <Award className="w-3.5 h-3.5 text-[#a78bfa] shrink-0" />
                  <span className="font-semibold text-slate-200">{tch.qualification}</span>
                </div>
                <div className="flex items-center gap-2">
                  <BookOpen className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>Subjects: {Array.isArray(tch.subjects) ? tch.subjects.join(', ') : tch.subjects}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="font-mono">{tch.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span className="text-[11px] font-mono text-slate-400">{tch.email}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-[#1e1e2e] flex items-center justify-between text-xs">
              <span className="text-slate-400">
                Monthly Scale: <strong className="font-mono text-white">৳{tch.salary?.toLocaleString()}</strong>
              </span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                  tch.status === 'Present'
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                    : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                }`}
              >
                {tch.status}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Add Teacher Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
          <div className="relative w-full max-w-xl bg-[#111118] text-slate-200 rounded-2xl shadow-2xl overflow-hidden border border-[#1e1e2e]">
            <div className="px-6 py-4 bg-[#16161f] border-b border-[#1e1e2e] flex items-center justify-between">
              <h3 className="font-bold text-sm text-white">Appoint Faculty Member</h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateTeacher} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-400 mb-1">Faculty Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full moom-input"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-400 mb-1">Designation</label>
                  <input
                    type="text"
                    value={formData.designation}
                    onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                    className="w-full moom-input"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-400 mb-1">Department</label>
                  <input
                    type="text"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full moom-input"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-400 mb-1">Academic Qualifications</label>
                  <input
                    type="text"
                    value={formData.qualification}
                    onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                    className="w-full moom-input"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-400 mb-1">Phone Number *</label>
                  <input
                    type="text"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full moom-input font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-400 mb-1">Email Address</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full moom-input font-mono"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-400 mb-1">Monthly Salary Scale (৳)</label>
                  <input
                    type="number"
                    value={formData.salary}
                    onChange={(e) => setFormData({ ...formData, salary: Number(e.target.value) })}
                    className="w-full moom-input font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-400 mb-1">Assigned Subjects (comma-separated)</label>
                  <input
                    type="text"
                    value={formData.subjects}
                    onChange={(e) => setFormData({ ...formData, subjects: e.target.value })}
                    className="w-full moom-input"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#1e1e2e]">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="moom-btn-ghost px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="moom-btn-primary px-6 py-2 rounded-xl font-bold shadow"
                >
                  Confirm Appointment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
