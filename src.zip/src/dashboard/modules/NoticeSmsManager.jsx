import { useState } from 'react'
import {
  Send,
  Bell,
  Smartphone,
  CheckCircle2,
  AlertCircle,
  Sparkles
} from 'lucide-react'
import { useDashboard } from '../context/DashboardContext'

export default function NoticeSmsManager() {
  const { smsLogs, sendSms, schoolInfo } = useDashboard()

  const [activeTab, setActiveTab] = useState('sms')
  const [targetGroup, setTargetGroup] = useState('All Class 10 Parents')
  const [recipientCount, setRecipientCount] = useState(138)
  const [smsText, setSmsText] = useState(
    'Dear Guardian, Class 10 Pre-Test examinations will commence from Oct 15, 2026. Please ensure regular attendance. - Mirashani Academy'
  )
  const [toastMessage, setToastMessage] = useState(null)

  const [noticeForm, setNoticeForm] = useState({
    title: '',
    category: 'Academic',
    priority: 'Urgent',
    content: ''
  })

  const templates = [
    {
      title: 'Exam Schedule Notice',
      text: `Dear Guardian, Half-Yearly Examination 2026 will commence from Oct 15. The examination timetable is posted on the portal. - ${schoolInfo.name}`
    },
    {
      title: 'Fee Due Reminder',
      text: `Dear Guardian, monthly academic fees and exam dues for the current term are requested to be cleared by the 10th of this month. - Accounts Office, ${schoolInfo.name}`
    },
    {
      title: 'Holiday Announcement',
      text: `Notice is hereby given that academic activities of the school will remain closed tomorrow due to official holiday. - ${schoolInfo.name}`
    },
    {
      title: 'Parent-Teacher Meeting',
      text: `Dear Guardian, a parent-teacher consultation meeting is scheduled for this Saturday at 10:00 AM in the school auditorium. Your presence is appreciated.`
    }
  ]

  const handleGroupChange = (grp) => {
    setTargetGroup(grp)
    if (grp.includes('All Students')) setRecipientCount(1250)
    else if (grp.includes('Class 10')) setRecipientCount(138)
    else if (grp.includes('Class 9')) setRecipientCount(142)
    else if (grp.includes('Faculty')) setRecipientCount(25)
    else setRecipientCount(45)
  }

  const handleSendSms = (e) => {
    e.preventDefault()
    if (!smsText.trim()) {
      alert('Please enter SMS message.')
      return
    }

    sendSms({
      recipientGroup: targetGroup,
      message: smsText,
      count: recipientCount
    })

    setToastMessage(`✓ SMS broadcast successfully dispatched to ${recipientCount} recipients!`)
    setTimeout(() => setToastMessage(null), 3500)
  }

  const handlePublishNotice = (e) => {
    e.preventDefault()
    if (!noticeForm.title || !noticeForm.content) {
      alert('Please provide notice title and description.')
      return
    }

    setToastMessage('✓ Notice published on official board successfully!')
    setNoticeForm({ title: '', category: 'Academic', priority: 'Urgent', content: '' })
    setTimeout(() => setToastMessage(null), 3500)
  }

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-[#16161f] text-white px-5 py-3 rounded-xl shadow-2xl border border-[#6c63ff]/40 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span className="font-semibold text-xs">{toastMessage}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 moom-card p-5">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2.5 py-1 rounded-full mb-1">
            <Send className="w-3.5 h-3.5" />
            <span>Communications Gateway & Broadcast Engine</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            SMS Broadcast & Notice Board
          </h2>
          <p className="text-xs text-slate-400">
            Automated parent SMS broadcast gateway with smartphone mockup preview and digital bulletin board
          </p>
        </div>

        <div className="flex bg-[#16161f] p-1 rounded-xl border border-[#1e1e2e]">
          <button
            onClick={() => setActiveTab('sms')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'sms' ? 'bg-[#6c63ff] text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Bulk SMS Gateway
          </button>
          <button
            onClick={() => setActiveTab('notice')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
              activeTab === 'notice' ? 'bg-[#6c63ff] text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Official Notices
          </button>
        </div>
      </div>

      {activeTab === 'sms' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* SMS Dispatcher Form */}
          <div className="lg:col-span-2 space-y-5">
            <div className="moom-card p-6">
              <h3 className="font-bold text-base text-white mb-4 flex items-center gap-2">
                <Send className="w-4 h-4 text-[#a78bfa]" />
                <span>Parent SMS Broadcast Console</span>
              </h3>

              <form onSubmit={handleSendSms} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-400 mb-1.5 uppercase tracking-wider">Target Recipient Group *</label>
                  <select
                    value={targetGroup}
                    onChange={(e) => handleGroupChange(e.target.value)}
                    className="w-full moom-select font-semibold"
                  >
                    <option value="All Class 10 Parents">Class 10 Parents (138 Guardians)</option>
                    <option value="All Class 9 Parents">Class 9 Parents (142 Guardians)</option>
                    <option value="All Students and Guardians">Entire Academy (1,250 Guardians)</option>
                    <option value="Fee Defaulter Students">Fee Overdue Students (45 Guardians)</option>
                    <option value="All Faculty and Staff">Faculty & Administration (25 Members)</option>
                  </select>
                </div>

                {/* Templates */}
                <div>
                  <label className="block font-bold text-slate-400 mb-1.5 uppercase tracking-wider">Pre-built Quick Templates</label>
                  <div className="flex flex-wrap gap-2">
                    {templates.map((tpl, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setSmsText(tpl.text)}
                        className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-[#6c63ff]/20 text-slate-300 hover:text-white font-medium text-xs border border-white/10 transition"
                      >
                        {tpl.title}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Message Field */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="font-bold text-slate-400 uppercase tracking-wider">SMS Message Content *</label>
                    <span className="font-mono text-slate-500 text-[11px]">
                      Characters: {smsText.length} · Parts: {Math.ceil(smsText.length / 160) || 1}
                    </span>
                  </div>
                  <textarea
                    rows={4}
                    required
                    value={smsText}
                    onChange={(e) => setSmsText(e.target.value)}
                    className="w-full moom-input"
                    placeholder="Type SMS text..."
                  />
                </div>

                <div className="bg-[#16161f] p-3.5 rounded-xl border border-[#1e1e2e] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-[#a78bfa]" />
                    <span className="text-slate-300">
                      Total Recipients: <strong className="text-white font-mono">{recipientCount}</strong>
                    </span>
                  </div>
                  <span className="text-emerald-400 font-mono text-xs">8,450 SMS Credits Available</span>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    type="submit"
                    className="moom-btn-primary px-6 py-2.5 rounded-xl font-bold text-xs inline-flex items-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>Broadcast Message</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Delivery History */}
            <div className="moom-table-container">
              <div className="p-4 bg-[#16161f] border-b border-[#1e1e2e] font-bold text-xs text-white uppercase tracking-wider">
                Recent Gateway Delivery Logs
              </div>
              <div className="divide-y divide-[#1e1e2e] text-xs">
                {smsLogs.map((log) => (
                  <div key={log.id} className="p-4 space-y-1.5 hover:bg-white/[0.01]">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">{log.recipientGroup}</span>
                      <span className="font-mono text-[11px] text-slate-500">{log.date}</span>
                    </div>
                    <p className="text-slate-300 text-xs leading-relaxed">{log.message}</p>
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-slate-500 font-mono text-[11px]">Count: {log.count} SMS</span>
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full">
                        {log.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Smartphone Live Preview Mockup (moom24 style) */}
          <div className="flex flex-col items-center">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
              Guardian Mobile Phone Preview
            </span>

            <div className="w-[280px] bg-[#16161f] rounded-[36px] p-3 shadow-2xl border-4 border-[#1e1e2e] relative">
              {/* Speaker Notch */}
              <div className="w-20 h-4 bg-black/60 rounded-b-xl mx-auto mb-3" />

              {/* Inner Screen */}
              <div className="bg-[#0a0a0f] rounded-[26px] p-3 min-h-[460px] flex flex-col justify-between text-slate-200 border border-[#1e1e2e]">
                <div className="border-b border-[#1e1e2e] pb-2 text-center">
                  <span className="font-mono text-[10px] text-slate-500">MESSAGES (SMS)</span>
                  <h4 className="font-bold text-xs text-white mt-0.5">{schoolInfo.eiin} - {schoolInfo.name}</h4>
                </div>

                <div className="space-y-3 my-auto">
                  <div className="bg-[#16161f] rounded-2xl rounded-tl-none p-3.5 shadow border border-[#1e1e2e] text-xs">
                    <p className="text-slate-200 leading-relaxed text-[11px]">
                      {smsText || 'Live preview of message appears here...'}
                    </p>
                    <span className="text-[9px] text-slate-500 font-mono block text-right mt-2">
                      Now · Delivered
                    </span>
                  </div>
                </div>

                <div className="border-t border-[#1e1e2e] pt-2 text-center text-[10px] text-slate-500">
                  Official SMS Gateway Channel
                </div>
              </div>

              {/* Home bar */}
              <div className="w-24 h-1 bg-white/30 rounded-full mx-auto mt-2" />
            </div>
          </div>
        </div>
      ) : (
        /* Notices Tab */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="moom-card p-6">
            <h3 className="font-bold text-base text-white mb-4 flex items-center gap-2">
              <Bell className="w-4 h-4 text-[#a78bfa]" />
              <span>Publish Official Notice</span>
            </h3>

            <form onSubmit={handlePublishNotice} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-bold text-slate-400 mb-1">Notice Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Schedule for Annual Science Fair"
                  value={noticeForm.title}
                  onChange={(e) => setNoticeForm({ ...noticeForm, title: e.target.value })}
                  className="w-full moom-input"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-400 mb-1">Category</label>
                <select
                  value={noticeForm.category}
                  onChange={(e) => setNoticeForm({ ...noticeForm, category: e.target.value })}
                  className="w-full moom-select"
                >
                  <option value="Academic">Academic Exams & Results</option>
                  <option value="Holiday">Vacation & Holidays</option>
                  <option value="Administrative">Administrative & Parent Meets</option>
                  <option value="Extracurricular">Sports & Cultural Fest</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-400 mb-1">Priority Level</label>
                <select
                  value={noticeForm.priority}
                  onChange={(e) => setNoticeForm({ ...noticeForm, priority: e.target.value })}
                  className="w-full moom-select"
                >
                  <option value="Urgent">Urgent Priority</option>
                  <option value="Normal">Normal Announcement</option>
                  <option value="Special">Special Institutional Notice</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-400 mb-1">Full Description *</label>
                <textarea
                  rows={5}
                  required
                  placeholder="Type the full notice body..."
                  value={noticeForm.content}
                  onChange={(e) => setNoticeForm({ ...noticeForm, content: e.target.value })}
                  className="w-full moom-input"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl moom-btn-primary font-bold text-xs shadow"
              >
                Post to Notice Board
              </button>
            </form>
          </div>

          <div className="lg:col-span-2 space-y-4">
            <h3 className="font-bold text-sm text-slate-400 uppercase tracking-wider">Active Published Bulletins</h3>

            <div className="space-y-3">
              <div className="moom-card p-5 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20 text-[10px] font-bold">
                    Urgent Notice
                  </span>
                  <span className="text-slate-500 font-mono text-[11px]">Published: Oct 02, 2026</span>
                </div>
                <h4 className="font-bold text-sm text-white">Half-Yearly Examination 2026 Routine Finalized</h4>
                <p className="text-slate-300 leading-relaxed text-xs">
                  All students and guardians are informed that Half-Yearly Examinations will commence on Oct 15. Admit cards will be available from the administration office upon clearance of institutional dues.
                </p>
                <div className="pt-2 border-t border-[#1e1e2e] flex items-center justify-between text-slate-400 text-[11px]">
                  <span>Authorized: {schoolInfo.principalName}</span>
                  <span className="text-[#a78bfa] font-semibold cursor-pointer hover:underline">Download PDF Document</span>
                </div>
              </div>

              <div className="moom-card p-5 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20 text-[10px] font-bold">
                    Academic Advisory
                  </span>
                  <span className="text-slate-500 font-mono text-[11px]">Published: Sep 28, 2026</span>
                </div>
                <h4 className="font-bold text-sm text-white">Special Practical Sessions for Class 10 Science Examinees</h4>
                <p className="text-slate-300 leading-relaxed text-xs">
                  Intensive physics and higher mathematics practical mentoring classes will be conducted daily from 03:00 PM to 04:15 PM in Science Labs 1 & 2.
                </p>
                <div className="pt-2 border-t border-[#1e1e2e] flex items-center justify-between text-slate-400 text-[11px]">
                  <span>Authorized: Prof. Dr. Shahinur Rahman, Asst. Headmaster</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
