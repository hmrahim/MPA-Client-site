import { createContext, useContext } from 'react'
import { translations, formatNumberByLang } from '../data/translations'

// The site is English-only. The provider keeps the same `t` / `num` / `lang`
// API so existing components keep working, but there is no language switching.
const LANG = 'en'

const value = {
  lang: LANG,
  t: (key, fallback = '') => translations[LANG][key] || fallback || key,
  num: (v) => formatNumberByLang(v, LANG)
}

const LanguageContext = createContext(value)

export function LanguageProvider({ children }) {
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  return useContext(LanguageContext)
}
