import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { ChevronLeft, ChevronRight, Calendar, ArrowRight, Sparkles, Award, ShieldCheck } from 'lucide-react'
import { slideImages } from '../data/content'
import { useLanguage } from '../context/LanguageContext'
import { translations } from '../data/translations'

const DURATION = 6000

export default function FullScreenBanner() {
  const { lang, num } = useLanguage()
  const [current, setCurrent] = useState(0)
  const [isPaused, setIsPaused] = useState(false)

  useEffect(() => {
    if (isPaused) return
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slideImages.length)
    }, DURATION)

    return () => clearInterval(timer)
  }, [current, isPaused])

  const nextSlide = () => {
    setCurrent((prev) => (prev + 1) % slideImages.length)
  }

  const prevSlide = () => {
    setCurrent((prev) => (prev - 1 + slideImages.length) % slideImages.length)
  }

  const goToSlide = (idx) => {
    setCurrent(idx)
  }

  const active = slideImages[current]
  const translatedSlide = (translations[lang] && translations[lang].slides && translations[lang].slides[current]) || active

  return (
    <div
      className="relative w-full h-[85vh] sm:h-[88vh] min-h-[520px] sm:min-h-[640px] max-h-[900px] overflow-hidden bg-board select-none"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      role="region"
      aria-label="Campus Highlights Slideshow"
    >
      {/* Background Slides */}
      {slideImages.map((slide, idx) => (
        <div
          key={slide.url}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            idx === current ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
          }`}
        >
          <img
            src={slide.url}
            alt={slide.title}
            className={`w-full h-full object-cover object-center ${
              idx === current ? 'scale-105 transition-transform duration-[7000ms] ease-out' : 'scale-100'
            }`}
          />
          {/* Dual Overlay Gradients for deep contrast and cinematic feel */}
          <div className="absolute inset-0 bg-gradient-to-r from-board/95 via-board/75 to-transparent/30" />
          <div className="absolute inset-0 bg-gradient-to-t from-board via-transparent/40 to-board/60" />
          {/* Subtle noise/mesh texture */}
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_rgba(255,255,255,0.15)_1px,_transparent_1px)] bg-[length:24px_24px]" />
        </div>
      ))}

      {/* Main Slide Content Area */}
      <div className="relative z-20 h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center pb-16 pt-12 sm:pb-20 sm:pt-16">
        <div className="max-w-3xl">
          {/* Top Badges */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3 mb-3 sm:mb-4 animate-fadeIn">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 sm:px-3.5 sm:py-1.5 rounded-full text-[11px] sm:text-xs font-bold tracking-wide uppercase bg-gold/20 text-gold border border-gold/40 backdrop-blur-md">
              <Sparkles className="w-3 sm:w-3.5 h-3 sm:h-3.5 animate-spin" style={{ animationDuration: '6s' }} />
              {translatedSlide.badge}
            </span>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 sm:px-3 rounded-full text-[11px] sm:text-xs font-medium text-chalk/90 bg-white/10 backdrop-blur-md border border-white/15">
              <Calendar className="w-3 sm:w-3.5 h-3 sm:h-3.5 text-mint" />
              {num(translatedSlide.date)}
            </span>
          </div>

          {/* Headline */}
          <h1
            key={`title-${current}-${lang}`}
            className="font-display font-extrabold text-2xl sm:text-5xl lg:text-6xl text-white tracking-tight leading-[1.18] sm:leading-[1.15] drop-shadow-lg"
          >
            {translatedSlide.title}
          </h1>

          {/* Subtitle */}
          <p
            key={`sub-${current}-${lang}`}
            className="mt-3 sm:mt-5 text-sm sm:text-lg lg:text-xl text-chalk/85 leading-relaxed max-w-2xl font-normal drop-shadow line-clamp-3 sm:line-clamp-none"
          >
            {translatedSlide.subtitle}
          </p>

          {/* CTA Buttons */}
          <div className="mt-6 sm:mt-8 flex flex-wrap items-center gap-2.5 sm:gap-4">
            <Link
              to={active.ctaLink}
              className="btn group inline-flex items-center gap-2 px-5 py-2.5 sm:px-7 sm:py-3.5 rounded-full font-bold text-xs sm:text-base text-ink bg-gold hover:brightness-110 shadow-[0_10px_25px_-5px_rgba(255,194,51,0.5)] transition-all transform hover:-translate-y-0.5"
            >
              <span>{translatedSlide.ctaText || active.ctaText}</span>
              <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4 transition-transform group-hover:translate-x-1" />
            </Link>

            <Link
              to="/results"
              className="btn inline-flex items-center gap-1.5 px-4 py-2.5 sm:px-6 sm:py-3.5 rounded-full font-bold text-xs sm:text-base text-white bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/25 transition-all transform hover:-translate-y-0.5"
            >
              <Award className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-gold" />
              <span>{lang === 'bn' ? 'ফলাফল অনুসন্ধান' : 'Check Result'}</span>
            </Link>

            <Link
              to="/admission"
              className="btn hidden sm:inline-flex items-center gap-2 px-6 py-3.5 rounded-full font-bold text-sm sm:text-base text-chalk bg-iris/80 hover:bg-iris border border-white/20 backdrop-blur-md transition-all transform hover:-translate-y-0.5"
            >
              <ShieldCheck className="w-4 h-4 text-mint" />
              <span>{lang === 'bn' ? 'অনলাইন ভর্তি' : 'Online Admission'}</span>
            </Link>
          </div>
        </div>
      </div>

      {/* Floating Left/Right Controls */}
      <div className="absolute z-20 left-2 sm:left-8 top-1/2 -translate-y-1/2">
        <button
          onClick={prevSlide}
          aria-label="Previous slide"
          className="w-9 h-9 sm:w-12 sm:h-12 rounded-full grid place-items-center bg-white/10 hover:bg-white/25 text-white backdrop-blur-md border border-white/20 transition-all hover:scale-110 active:scale-95 shadow-xl cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
        </button>
      </div>

      <div className="absolute z-20 right-2 sm:right-8 top-1/2 -translate-y-1/2">
        <button
          onClick={nextSlide}
          aria-label="Next slide"
          className="w-9 h-9 sm:w-12 sm:h-12 rounded-full grid place-items-center bg-white/10 hover:bg-white/25 text-white backdrop-blur-md border border-white/20 transition-all hover:scale-110 active:scale-95 shadow-xl cursor-pointer"
        >
          <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
        </button>
      </div>

      {/* Sleek Minimal Slide Dots (No title tags, no scrollbars) */}
      <div className="absolute z-20 bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-2 pointer-events-auto">
        {slideImages.map((_, idx) => (
          <button
            key={idx}
            onClick={() => goToSlide(idx)}
            aria-label={`Go to slide ${idx + 1}`}
            className={`transition-all duration-300 rounded-full cursor-pointer ${
              idx === current
                ? 'w-8 h-2.5 bg-gold shadow-md'
                : 'w-2.5 h-2.5 bg-white/40 hover:bg-white/80'
            }`}
          />
        ))}
      </div>
    </div>
  )
}
