import { useState } from 'react'
import Reveal from './Reveal'
import { notices } from '../data/content'
import { useLanguage } from '../context/LanguageContext'

export default function Notices() {
  const { lang, t } = useLanguage()
  const noticeList = notices[lang] || notices.bn

  const allLabel = lang === 'bn' ? 'সব' : 'All'
  const cats = [allLabel, ...new Set(noticeList.map((n) => n.cat))]
  const [cat, setCat] = useState(allLabel)

  // Reset to 'all' when language changes (cat label changes)
  const shown = noticeList.filter((n) => cat === allLabel || n.cat === cat)

  return (
    <section id="notices" className="max-w-6xl mx-auto px-4 py-16 scroll-mt-24">
      <Reveal as="h2" className="sec-title font-display">{t('noticeHeading')}</Reveal>
      <Reveal as="p" delay={90} className="text-ink/70 mt-1">
        {lang === 'bn' ? 'বিদ্যালয় কার্যালয়ের প্রতিটি ঘোষণা এক জায়গায়।' : 'Every announcement from the school office, in one place.'}
      </Reveal>

      <Reveal delay={180} className="mt-6 flex flex-wrap gap-2">
        {cats.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            aria-pressed={c === cat}
            className={`px-4 py-2 rounded-full border border-ink/25 text-sm font-medium ${c === cat ? 'tab-on' : 'bg-white'}`}
          >
            {c}
          </button>
        ))}
      </Reveal>

      <Reveal delay={270} className="pop-in mt-6 grid md:grid-cols-2 gap-4">
        {shown.map((n) => (
          <article key={n.id} data-tilt className="card notice-card">
            <div className="flex justify-between text-xs">
              <span className="font-bold text-brick">{n.cat}</span>
              <span className="text-ink/60">{n.date}</span>
            </div>
            <h3 className="font-display font-bold text-lg mt-2">{n.title}</h3>
            <p className="text-sm text-ink/75 mt-1">{n.text}</p>
            {n.file && (
              <a href={n.file} className="inline-block mt-3 text-sm font-bold underline underline-offset-4">
                {lang === 'bn' ? 'পিডিএফ ডাউনলোড করুন' : 'Download PDF'}
              </a>
            )}
          </article>
        ))}
      </Reveal>
    </section>
  )
}
